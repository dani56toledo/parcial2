Imports System

Module Program
    Public Class corteindustrial
        Public color As String
        Public piezas As Integer
        Public talla As String
        Public turno As Integer
        Public piesastot As Integer

        Public Sub ingresartam()

            Console.WriteLine("Ingresa la talla de la falda")
            talla = Console.ReadLine()

            Console.WriteLine("Ingresa el color de la falda")
            color = Console.ReadLine()

            Console.WriteLine("Ingresa el numero de prendas a realizar de la falda")

            piezas = Console.ReadLine()

        End Sub
        Public Sub sacdatos()

            Console.WriteLine("las faldas " & color & " constan de 5 piezas para cortar y
se confeccionarian " & piezas & " ,entonces el total de piezas es:. ")

        End Sub
        Public Sub calc()

            piesastot = 5 * piezas

            Console.WriteLine(piesastot & " :)")

        End Sub

        Public Function calctot()

            piesastot = 5 * piezas

            Return piesastot
        End Function
    End Class
    Sub Main(args As String())
        Dim piezastt As Single
        Dim pieza1 As corteindustrial
        pieza1 = New corteindustrial()
        pieza1.ingresartam()
        pieza1.sacdatos()
        pieza1.calc()
        pieza1.calctot()

        Dim pieza2 As corteindustrial
        pieza2 = New corteindustrial()
        pieza2.ingresartam()
        pieza2.sacdatos()
        pieza2.calc()
        pieza2.calctot()

        Dim pieza3 As corteindustrial
        pieza3 = New corteindustrial()
        pieza3.ingresartam()
        pieza3.sacdatos()
        pieza3.calc()
        pieza3.calctot()

        Dim pieza4 As corteindustrial
        pieza4 = New corteindustrial()
        pieza4.ingresartam()
        pieza4.sacdatos()
        pieza4.calc()
        pieza4.calctot()

        Dim pieza5 As corteindustrial
        pieza5 = New corteindustrial()
        pieza5.ingresartam()
        pieza5.sacdatos()
        pieza5.calc()
        pieza5.calctot()


        piezastt = pieza2.calctot() + pieza1.calctot() + pieza3.calctot() + pieza4.calctot() + pieza5.calctot()
        Console.WriteLine(" Tus piezas totales son " & piezastt & " :)")

    End Sub
End Module
